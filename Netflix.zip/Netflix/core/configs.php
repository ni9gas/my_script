<?php 

/**

 * @telegram   :   @Lordqiezt+ 
 */



$bot_token = "8186812530:AAFsijM2-Q2NnYPGmj4UM_sC3XU3ty3ytxM"; // token
$chat_ids = "-6251439446"; // chat ID


?>