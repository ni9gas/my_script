<?php
/*  
 
 ()()                ____
 (..)               /|o  |
 /\/\              /o|  o|
c\db/o............/o_|_o_|
                                                               
*/
    
    // error_reporting(0);
    // error_reporting(E_ERROR | E_PARSE);
    session_start();
    include_once 'defender.php';
    require_once 'detect.php';
?>