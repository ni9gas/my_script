
put your info config.php